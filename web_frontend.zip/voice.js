document.addEventListener('DOMContentLoaded', () => {
    const btnMic = document.getElementById('btnMic');
    const transcriptText = document.getElementById('transcriptText');
    const btnAnalyzeVoice = document.getElementById('btnAnalyzeVoice');
    
    let isRecording = false;
    let recognition = null;
    let finalTranscript = '';

    // Initialize Web Speech API
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        
        recognition.onstart = () => {
            isRecording = true;
            btnMic.classList.add('recording');
        };
        
        recognition.onresult = (event) => {
            let interimTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript + ' ';
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }
            
            transcriptText.innerText = finalTranscript + interimTranscript;
            
            if (transcriptText.innerText.trim().length > 0) {
                btnAnalyzeVoice.disabled = false;
                btnAnalyzeVoice.classList.add('active');
            } else {
                btnAnalyzeVoice.disabled = true;
                btnAnalyzeVoice.classList.remove('active');
            }
        };
        
        recognition.onerror = (event) => {
            console.error('Speech recognition error', event.error);
            stopRecording();
        };
        
        recognition.onend = () => {
            stopRecording();
        };
    } else {
        alert("Your browser does not support Speech Recognition. You can type in the transcript box manually.");
        transcriptText.addEventListener('input', () => {
            if (transcriptText.innerText.trim().length > 0) {
                btnAnalyzeVoice.disabled = false;
                btnAnalyzeVoice.classList.add('active');
            } else {
                btnAnalyzeVoice.disabled = true;
                btnAnalyzeVoice.classList.remove('active');
            }
        });
    }

    const stopRecording = () => {
        isRecording = false;
        btnMic.classList.remove('recording');
        if (recognition) {
            recognition.stop();
        }
    };

    btnMic.addEventListener('click', () => {
        if (isRecording) {
            stopRecording();
        } else {
            if (recognition) {
                recognition.start();
            } else {
                alert("Speech recognition not supported.");
            }
        }
    });

    // Also allow manual typing
    transcriptText.addEventListener('input', () => {
        if (transcriptText.innerText.trim().length > 0) {
            btnAnalyzeVoice.disabled = false;
            btnAnalyzeVoice.classList.add('active');
        } else {
            btnAnalyzeVoice.disabled = true;
            btnAnalyzeVoice.classList.remove('active');
        }
    });

    btnAnalyzeVoice.addEventListener('click', async () => {
        const textToAnalyze = transcriptText.innerText.trim();
        if (!textToAnalyze) return;
        
        const originalText = btnAnalyzeVoice.innerHTML;
        btnAnalyzeVoice.innerHTML = 'ANALYZING...';
        btnAnalyzeVoice.disabled = true;
        
        // Fetch user data for age/gender if available
        let age = "Unknown";
        let gender = "Unknown";
        const userStr = localStorage.getItem('user');
        if (userStr) {
            try {
                const user = JSON.parse(userStr);
                if (user.age) age = user.age;
                if (user.gender) gender = user.gender;
            } catch (e) {}
        }
        
        try {
            const response = await fetch('http://localhost/symto_tracker/api/analyze.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    symptomsText: textToAnalyze,
                    age: age,
                    gender: gender,
                    conditions: [] 
                })
            });
            const data = await response.json();
            
            if (data.error) {
                alert("Analysis failed: " + data.error);
                btnAnalyzeVoice.innerHTML = originalText;
                btnAnalyzeVoice.disabled = false;
            } else {
                sessionStorage.setItem("analysisResult", JSON.stringify(data));
                window.location.href = "result.html";
            }
        } catch (err) {
            console.error('Error analyzing voice input:', err);
            alert("Error connecting to backend.");
            btnAnalyzeVoice.innerHTML = originalText;
            btnAnalyzeVoice.disabled = false;
        }
    });
});
