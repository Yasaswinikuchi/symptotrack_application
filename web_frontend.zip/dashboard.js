document.addEventListener('DOMContentLoaded', async () => {
    const userNameElement = document.getElementById('userName');
    
    try {
        const userStr = localStorage.getItem('user');
        if (userStr) {
            const user = JSON.parse(userStr);
            userNameElement.textContent = user.name;
        } else {
            userNameElement.textContent = 'Guest User';
        }
    } catch (error) {
        console.error('Failed to parse user:', error);
        userNameElement.textContent = 'Guest User';
    }

    // Emergency Banner Click
    const emergencyBanner = document.querySelector('.emergency-banner');
    if (emergencyBanner) {
        emergencyBanner.addEventListener('click', () => {
            alert('Mock: Dialing Emergency Services...');
        });
    }

    // Removed btnScanImage inline logic to use scan.html
    // Removed btnVoiceInput inline logic to use voice.html
    const btnCheckScore = document.getElementById('btnCheckScore');

    if (btnCheckScore) {
        btnCheckScore.addEventListener('click', async () => {
            try {
                const response = await fetch('http://localhost/symto_tracker/api/health.php');
                const data = await response.json();
                if (data.status === 'ok') {
                    alert('Health check passed. Backend is running.');
                } else {
                    alert('Health check failed.');
                }
            } catch (err) {
                alert('Health check failed to connect to backend.');
            }
        });
    }
});
