document.addEventListener("DOMContentLoaded", () => {
    const analyzeBtn = document.getElementById("analyzeBtn");
    const conditionsContainer = document.getElementById("conditionsContainer");
    const addConditionBtn = document.getElementById("addConditionBtn");

    // Add new condition
    addConditionBtn.addEventListener("click", () => {
        const conditionText = prompt("Enter pre-existing condition:");
        if (conditionText && conditionText.trim() !== "") {
            const pill = document.createElement("span");
            pill.className = "condition-pill";
            pill.innerHTML = `${conditionText} <span class="remove-pill">&times;</span>`;
            conditionsContainer.insertBefore(pill, addConditionBtn);
        }
    });

    // Remove condition pill
    conditionsContainer.addEventListener("click", (e) => {
        if (e.target.classList.contains("remove-pill")) {
            e.target.parentElement.remove();
        }
    });

    // Analyze symptoms
    analyzeBtn.addEventListener("click", () => {
        const symptomsText = document.getElementById("symptomsText").value;
        const age = document.getElementById("patientAge").value;
        const gender = document.getElementById("patientGender").value;
        const conditions = Array.from(conditionsContainer.querySelectorAll(".condition-pill")).map(pill => pill.childNodes[0].textContent.trim());

        if (!symptomsText || symptomsText.trim() === "") {
            alert("Please describe how you feel before analyzing.");
            return;
        }

        analyzeBtn.innerHTML = `Analyzing...`;
        analyzeBtn.disabled = true;

        fetch("http://localhost/symto_tracker/api/analyze.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ symptomsText, age, gender, conditions })
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert("Analysis failed: " + data.error);
                analyzeBtn.innerHTML = `Analyze Symptoms`;
                analyzeBtn.disabled = false;
            } else {
                sessionStorage.setItem("analysisResult", JSON.stringify(data));
                window.location.href = "result.html";
            }
        })
        .catch(err => {
            alert("Error connecting to backend.");
            analyzeBtn.innerHTML = `Analyze Symptoms`;
            analyzeBtn.disabled = false;
        });
    });
});
