document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('fullname').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const submitBtn = signupForm.querySelector('.btn-primary');
        const originalText = submitBtn.textContent;
        
        // Basic validation
        if (!name || !email || !password) {
            alert('Please fill in all fields');
            return;
        }

        submitBtn.textContent = 'Signing up...';
        submitBtn.disabled = true;

        try {
            // Send request to PHP backend
            const response = await fetch(signupForm.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                localStorage.setItem('user', JSON.stringify(result.user));
                window.location.href = 'dashboard.html';
            } else {
                alert('Sign Up failed: ' + result.message);
            }
        } catch (error) {
            console.error('Error signing up:', error);
            alert('An error occurred. Make sure your local server is running.');
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
});
