document.addEventListener("DOMContentLoaded", () => {
    fetchProfile();

    document.getElementById("btnSaveProfile").addEventListener("click", () => {
        const name = document.getElementById("editName").value;
        const email = document.getElementById("editEmail").value;

        if (!name || !email) {
            alert("Name and email are required");
            return;
        }

        fetch("http://localhost/symto_tracker/api/profile.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name, email })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("Profile updated successfully!");
                const userStr = localStorage.getItem('user');
                if (userStr) {
                    const user = JSON.parse(userStr);
                    user.name = name;
                    user.email = email;
                    localStorage.setItem('user', JSON.stringify(user));
                }
                closeModal('personalInfoModal');
                fetchProfile();
            } else {
                alert(data.error || "Failed to update profile");
            }
        })
        .catch(err => alert("Error updating profile"));
    });

    document.getElementById("btnSavePassword").addEventListener("click", () => {
        const name = document.getElementById("editName").value;
        const email = document.getElementById("editEmail").value;
        const pwd = document.getElementById("editPassword").value;
        const pwdConfirm = document.getElementById("editPasswordConfirm").value;

        if (!pwd) {
            alert("Please enter a new password");
            return;
        }
        if (pwd !== pwdConfirm) {
            alert("Passwords do not match!");
            return;
        }

        fetch("http://localhost/symto_tracker/api/profile.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name, email, password: pwd })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("Password changed successfully!");
                document.getElementById("editPassword").value = "";
                document.getElementById("editPasswordConfirm").value = "";
                closeModal('changePasswordModal');
            } else {
                alert(data.error || "Failed to change password");
            }
        })
        .catch(err => alert("Error changing password"));
    });

    document.getElementById("btnDeleteAccount").addEventListener("click", () => {
        if (confirm("Are you SURE you want to delete your account? This action cannot be undone.")) {
            fetch("http://localhost/symto_tracker/api/delete_account.php", {
                method: "POST"
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert("Account deleted. You will be logged out.");
                    window.location.href = "login.html";
                } else {
                    alert(data.error || "Failed to delete account");
                }
            })
            .catch(err => alert("Error deleting account"));
        }
    });

    const btnLogout = document.getElementById("btnLogout");
    if (btnLogout) {
        btnLogout.addEventListener("click", () => {
            alert("Logged out successfully.");
            sessionStorage.clear();
            window.location.href = "login.html";
        });
    }
});

function fetchProfile() {
    const userStr = localStorage.getItem('user');
    if (userStr) {
        try {
            const data = JSON.parse(userStr);
            document.getElementById("profileName").innerText = data.name || "Guest User";
            document.getElementById("profileEmail").innerText = data.email || "No email";
            document.getElementById("editName").value = data.name || "";
            document.getElementById("editEmail").value = data.email || "";
        } catch (e) {
            console.error("Failed to parse user from localStorage", e);
        }
    } else {
        document.getElementById("profileName").innerText = "Guest User";
        document.getElementById("profileEmail").innerText = "No email";
    }
}

function openModal(modalId) {
    document.getElementById(modalId).style.display = "flex";
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}
