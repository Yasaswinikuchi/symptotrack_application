document.addEventListener("DOMContentLoaded", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                initMap(lat, lon);
            },
            (error) => {
                if (error.code === error.PERMISSION_DENIED) {
                    alert("Location access was denied! Please click the location icon in your URL bar, select 'Allow', and refresh the page to see live nearby clinics.");
                }
                
                // Fallback location if geolocation fails or is denied
                const lat = 14.4536;
                const lon = 79.9867;
                initMap(lat, lon);
            },
            { enableHighAccuracy: true, timeout: 5000 }
        );
    } else {
        document.getElementById('loadingText').innerText = "Geolocation not supported by this browser.";
    }
});

let map;
function initMap(lat, lon) {
    document.getElementById('loadingText').innerText = "Fetching nearby hospitals...";
    
    map = L.map('map').setView([lat, lon], 13);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    }).addTo(map);

    // Add user marker
    if (window.userMarker) {
        map.removeLayer(window.userMarker);
    }
    window.userMarker = L.marker([lat, lon]).addTo(map)
        .bindPopup('You are here (Click anywhere to change)')
        .openPopup();

    // Add click event to map to change location
    map.off('click'); // remove previous listeners
    map.on('click', function(e) {
        const newLat = e.latlng.lat;
        const newLon = e.latlng.lng;
        document.getElementById('loadingText').innerText = "Updating location...";
        map.setView([newLat, newLon], 13);
        
        if (window.userMarker) {
            map.removeLayer(window.userMarker);
        }
        window.userMarker = L.marker([newLat, newLon]).addTo(map)
            .bindPopup('You are here')
            .openPopup();
            
        fetchHospitals(newLat, newLon);
    });

    fetchHospitals(lat, lon);
}

// Search functionality
document.addEventListener("DOMContentLoaded", () => {
    const searchBtn = document.getElementById('btnSearchLocation');
    const searchInput = document.getElementById('locationSearch');
    
    if (searchBtn && searchInput) {
        const performSearch = () => {
            const query = searchInput.value.trim();
            if (!query) return;
            
            document.getElementById('loadingText').innerText = "Searching for location...";
            searchBtn.disabled = true;
            
            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    searchBtn.disabled = false;
                    if (data && data.length > 0) {
                        const newLat = parseFloat(data[0].lat);
                        const newLon = parseFloat(data[0].lon);
                        
                        document.getElementById('loadingText').innerText = "Updating location...";
                        map.setView([newLat, newLon], 13);
                        
                        if (window.userMarker) {
                            map.removeLayer(window.userMarker);
                        }
                        window.userMarker = L.marker([newLat, newLon]).addTo(map)
                            .bindPopup('Searched Location')
                            .openPopup();
                            
                        fetchHospitals(newLat, newLon);
                    } else {
                        document.getElementById('loadingText').innerText = "Location not found. Try another search.";
                    }
                })
                .catch(err => {
                    searchBtn.disabled = false;
                    document.getElementById('loadingText').innerText = "Error searching location.";
                    console.error(err);
                });
        };

        searchBtn.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
});

window.hospitalMarkers = window.hospitalMarkers || [];

function fetchHospitals(lat, lon) {
    // Overpass API to find hospitals within ~5000 meters
    const url = `http://localhost/symto_tracker/api/hospitals.php?lat=${lat}&lon=${lon}`;

    fetch(url)
    .then(res => {
        if (!res.ok) throw new Error("API returned " + res.status);
        return res.json();
    })
    .then(data => {
        const listDiv = document.getElementById('hospitalList');
        listDiv.innerHTML = '';
        
        // Clear previous markers
        window.hospitalMarkers.forEach(m => map.removeLayer(m));
        window.hospitalMarkers = [];

        if (!data.elements || data.elements.length === 0) {
            listDiv.innerHTML = '<p style="text-align: center; color: #64748B;">No hospitals found nearby.</p>';
            document.getElementById('loadingText').innerText = "Try tapping elsewhere on the map.";
            return;
        }

        document.getElementById('loadingText').innerText = "Found hospitals nearby!";

        // Limit to 5 results for demo
        const elements = data.elements.slice(0, 5);
        
        elements.forEach(el => {
            const hLat = el.lat;
            const hLon = el.lon;
            const name = el.tags.name || "Unknown Clinic";
            
            // Add map marker
            const marker = L.marker([hLat, hLon]).addTo(map).bindPopup(name);
            window.hospitalMarkers.push(marker);

            // Create card
            const card = document.createElement('div');
            card.className = 'hospital-card';
            
            // Calculate mock distance and wait time
            const dist = (Math.random() * 5 + 0.5).toFixed(1);
            const waitTime = Math.floor(Math.random() * 60 + 5);
            const rating = (Math.random() * 1.5 + 3.5).toFixed(1);

            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                    <div>
                        <h3 style="font-size: 16px; font-weight: 700; color: #0F172A; margin-bottom: 4px;">${name}</h3>
                        <p style="font-size: 13px; color: #64748B;">General Hospital</p>
                    </div>
                    <div style="background-color: #FEF3C7; padding: 4px 8px; border-radius: 8px; display: flex; align-items: center;">
                        <svg viewBox="0 0 24 24" fill="#D97706" style="width: 12px; height: 12px; margin-right: 4px;" xmlns="http://www.w3.org/2000/svg"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                        <span style="font-size: 12px; font-weight: 700; color: #B45309;">${rating}</span>
                    </div>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 16px;">
                    <div style="display: flex; align-items: center; margin-right: 16px;">
                        <svg viewBox="0 0 24 24" fill="none" style="width: 14px; height: 14px; margin-right: 4px;" xmlns="http://www.w3.org/2000/svg"><path d="M12 21a9 9 0 100-18 9 9 0 000 18z" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 6v6l4 2" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span style="font-size: 13px; color: #64748B;">Wait: ${waitTime} min</span>
                    </div>
                    <div style="display: flex; align-items: center;">
                        <svg viewBox="0 0 24 24" fill="none" style="width: 14px; height: 14px; margin-right: 4px;" xmlns="http://www.w3.org/2000/svg"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1118 0z" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="10" r="3" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span style="font-size: 13px; color: #64748B;">${dist} km</span>
                    </div>
                </div>
                <button class="btn-primary" onclick="bookAppointment('${name.replace(/'/g, "\\'")}')">Book Appointment (₹500)</button>
            `;
            listDiv.appendChild(card);
        });
    })
    .catch(err => {
        document.getElementById('loadingText').innerText = "Failed to load hospitals: " + err.message;
        console.error(err);
    });
}

let currentBookingHospital = "";

function bookAppointment(hospitalName) {
    currentBookingHospital = hospitalName;
    document.getElementById('modalHospitalName').innerText = "Book: " + hospitalName;
    document.getElementById('bookingProblem').value = "";
    document.getElementById('bookingTimeSlot').value = "";
    document.getElementById('bookingModal').style.display = "flex";
}

function closeBookingModal() {
    document.getElementById('bookingModal').style.display = "none";
}

function proceedToPay() {
    const problem = document.getElementById('bookingProblem').value.trim();
    const date = document.getElementById('bookingDate').value;
    const timeSlot = document.getElementById('bookingTimeSlot').value;

    if (!problem || !date || !timeSlot) {
        alert("Please describe your problem, select a date, and select a time slot.");
        return;
    }

    // Close modal
    closeBookingModal();

    fetch("http://localhost/symto_tracker/api/create_order.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: 50000 }) // 500 INR
    })
    .then(res => res.json())
    .then(orderData => {
        if (!orderData.id) {
            alert("Failed to create order");
            return;
        }

        var options = {
            "key": "rzp_test_SqOZwDnHPrqJm0", 
            "amount": "50000",
            "currency": "INR",
            "name": "SymptoTrack",
            "description": "Appointment at " + currentBookingHospital,
            "order_id": orderData.id,
            "handler": function (response) {
                fetch("http://localhost/symto_tracker/api/verify_payment.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_signature: response.razorpay_signature
                    })
                })
                .then(vRes => vRes.json())
                .then(vData => {
                    if (vData.success) {
                        fetch("http://localhost/symto_tracker/api/save_appointment.php", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                hospital_name: currentBookingHospital,
                                payment_id: response.razorpay_payment_id,
                                problem_description: problem,
                                date: date,
                                time_slot: timeSlot
                            })
                        }).then(() => {
                            alert("Appointment Booked Successfully!");
                        });
                    } else {
                        alert("Payment Verification Failed!");
                    }
                });
            },
            "prefill": {
                "name": "Alex Johnson",
                "email": "alex.johnson@example.com",
                "contact": "9999999999"
            },
            "theme": {
                "color": "#3B82F6"
            }
        };
        var rzp1 = new Razorpay(options);
        rzp1.open();
    })
    .catch(err => {
        console.error(err);
        alert("Error initiating payment");
    });
}
