document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const submitBtn = loginForm.querySelector('.btn-primary');
        const originalText = submitBtn.textContent;
        
        // Basic validation
        if (!email || !password) {
            alert('Please fill in all fields');
            return;
        }

        submitBtn.textContent = 'Logging in...';
        submitBtn.disabled = true;

        try {
            // Send request to PHP backend
            const response = await fetch(loginForm.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                localStorage.setItem('user', JSON.stringify(result.user));
                localStorage.setItem('token', result.token);
                window.location.href = 'dashboard.html';
            } else {
                alert('Login failed: ' + result.message);
            }
        } catch (error) {
            console.error('Error logging in:', error);
            alert('An error occurred. Make sure your local server is running.');
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
});
