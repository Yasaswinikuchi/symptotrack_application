let historyData = [];

function openReportModal(index) {
    const record = historyData[index];
    
    if (!record.full_response) {
        alert("This is an older record. Detailed report is not available.");
        return;
    }

    sessionStorage.setItem("historyResult", record.full_response);
    sessionStorage.setItem("historyReportId", record.id);
    
    window.location.href = "history_result.html";
}

function cancelAppointment(id) {
    if (confirm("Are you sure you want to cancel this appointment?")) {
        fetch("http://localhost/symto_tracker/api/delete_appointment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: id })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("Appointment cancelled.");
                location.reload();
            } else {
                alert(data.error || "Failed to cancel appointment.");
            }
        })
        .catch(err => {
            console.error(err);
            alert("Error cancelling appointment.");
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const historyList = document.getElementById("historyList");
    const appointmentsList = document.getElementById("appointmentsList");
    const btnClearAll = document.getElementById("btnClearAll");

    if (appointmentsList) {
        fetch("http://localhost/symto_tracker/api/get_appointments.php")
            .then(res => res.json())
            .then(data => {
                if (data.error || !data.success) {
                    appointmentsList.innerHTML = `<div style="text-align: center; color: #DC2626; padding: 20px;">Failed to load appointments.</div>`;
                    return;
                }
                if (!data.data || data.data.length === 0) {
                    appointmentsList.innerHTML = `<div style="text-align: center; color: #64748B; padding: 20px;">No appointments found.</div>`;
                    return;
                }
                const html = data.data.map(apt => {
                    return `
                    <div class="history-card" style="margin-bottom: 12px;">
                        <div class="history-icon" style="background-color: #E0E7FF;">
                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 4H5C3.89543 4 3 4.89543 3 6V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V6C21 4.89543 20.1046 4 19 4Z" stroke="#4F46E5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M16 2V6M8 2V6M3 10H21" stroke="#4F46E5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="history-content">
                            <div class="history-header">
                                <h3 class="history-title">${apt.hospital_name}</h3>
                                <span class="history-badge badge-green">${apt.time_slot}</span>
                            </div>
                            <div class="history-desc">Problem: ${apt.problem_description || 'N/A'}</div>
                        </div>
                        <div class="history-arrow">
                            <button onclick="cancelAppointment(${apt.id})" style="background:none; border:none; color:#EF4444; font-weight:600; cursor:pointer; font-size: 13px;">Cancel</button>
                        </div>
                    </div>
                    `;
                }).join("");
                appointmentsList.innerHTML = html;
            })
            .catch(err => {
                appointmentsList.innerHTML = `<div style="text-align: center; color: #DC2626; padding: 20px;">Failed to fetch: ${err.message}</div>`;
            });
    }


    if (btnClearAll) {
        btnClearAll.addEventListener("click", () => {
            if (historyData.length === 0) {
                alert("No history to clear.");
                return;
            }
            if (confirm("Are you sure you want to delete all history records? This cannot be undone.")) {
                fetch("http://localhost/symto_tracker/api/clear_history.php", {
                    method: "POST"
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert("All records deleted.");
                        location.reload();
                    } else {
                        alert(data.error || "Failed to clear history");
                    }
                })
                .catch(err => {
                    alert("Error clearing history");
                    console.error(err);
                });
            }
        });
    }

    fetch("http://localhost/symto_tracker/api/history.php")
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                historyList.innerHTML = `<div style="text-align: center; color: #DC2626; padding: 20px;">Database Error: ${data.error}</div>`;
                return;
            }
            if (data.length === 0) {
                historyList.innerHTML = `<div style="text-align: center; color: #64748B; padding: 20px;">No history records found.</div>`;
                return;
            }

            historyData = data;

            const html = data.map((record, index) => {
                const dateObj = new Date(record.created_at);
                const dateStr = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
                
                let badgeClass = "badge-green";
                if (record.risk_level === "Medium") badgeClass = "badge-orange";
                if (record.risk_level === "High") badgeClass = "badge-red";

                // Icon logic based on type
                let iconSvg = `<path d="M8 7V3M16 7V3M7 11H17M5 21H19C20.1046 21 21 20.1046 21 19V7C21 5.89543 20.1046 5 19 5H5C3.89543 5 3 5.89543 3 7V19C3 20.1046 3.89543 21 5 21Z" stroke="#3B82F6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`;
                if (record.type === "Image Scan") {
                    iconSvg = `<path d="M22 12h-4l-3 9L9 3l-3 9H2" stroke="#3B82F6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`;
                }

                return `
                <div class="history-card" onclick="openReportModal(${index})" style="cursor: pointer;">
                    <div class="history-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            ${iconSvg}
                        </svg>
                    </div>
                    <div class="history-content">
                        <div class="history-header">
                            <h3 class="history-title">${record.type}</h3>
                            <span class="history-badge ${badgeClass}">${record.risk_level}</span>
                        </div>
                        <div class="history-date">${dateStr}</div>
                        <div class="history-desc">${record.symptoms}</div>
                    </div>
                    <div class="history-arrow">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 18l6-6-6-6" stroke="#CBD5E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
                `;
            }).join("");

            historyList.innerHTML = html;
        })
        .catch(err => {
            historyList.innerHTML = `<div style="text-align: center; color: #DC2626; padding: 20px;">Failed to fetch: ${err.message}</div>`;
        });
});
