document.addEventListener('DOMContentLoaded', () => {
    const btnTakePhoto = document.getElementById('btnTakePhoto');
    const btnUploadFile = document.getElementById('btnUploadFile');
    const btnAnalyzeImage = document.getElementById('btnAnalyzeImage');
    
    const cameraInput = document.getElementById('cameraInput');
    const uploadInput = document.getElementById('uploadInput');
    
    const imagePreview = document.getElementById('imagePreview');
    const placeholderContent = document.getElementById('placeholderContent');
    
    let currentBase64Image = null;

    btnTakePhoto.addEventListener('click', () => {
        cameraInput.click();
    });

    btnUploadFile.addEventListener('click', () => {
        uploadInput.click();
    });

    const handleFileSelect = (e) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            
            reader.onload = (event) => {
                const result = event.target.result;
                currentBase64Image = result.split(',')[1];
                
                imagePreview.src = result;
                imagePreview.style.display = 'block';
                placeholderContent.style.display = 'none';
                
                btnAnalyzeImage.disabled = false;
            };
            
            reader.readAsDataURL(file);
        }
    };

    cameraInput.addEventListener('change', handleFileSelect);
    uploadInput.addEventListener('change', handleFileSelect);

    btnAnalyzeImage.addEventListener('click', async () => {
        if (!currentBase64Image) return;
        
        const originalText = btnAnalyzeImage.textContent;
        btnAnalyzeImage.textContent = 'ANALYZING...';
        btnAnalyzeImage.disabled = true;
        
        try {
            const response = await fetch('http://localhost/symto_tracker/api/analyze_image.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image: currentBase64Image })
            });
            const data = await response.json();
            
            if (data.error) {
                alert("Analysis failed: " + data.error);
                btnAnalyzeImage.textContent = originalText;
                btnAnalyzeImage.disabled = false;
            } else {
                sessionStorage.setItem("analysisResult", JSON.stringify(data));
                window.location.href = "result.html";
            }
        } catch (err) {
            console.error('Error analyzing image:', err);
            alert("Error connecting to backend.");
            btnAnalyzeImage.textContent = originalText;
            btnAnalyzeImage.disabled = false;
        }
    });
});
